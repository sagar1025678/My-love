# For Binita ♡ — From Sagar

A romantic, mobile-friendly one-page website made with plain HTML, CSS, and JavaScript. No frameworks or paid services needed.

## Preview on your computer
1. Download and unzip the folder.
2. Open `index.html` in a browser.

## Publish it with GitHub Pages
1. Sign in to GitHub and create a **new public repository** (for example, `for-binita`).
2. Upload `index.html` to the repository's root. You can also upload this README.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. GitHub will show your website URL in the Pages section, usually:
   `https://YOUR-USERNAME.github.io/for-binita/`

## Personalize it
Open `index.html` in a text editor and search for the message or names you want to change. The site currently uses **Sagar** and **Binita**. There is no music by default, so it won't unexpectedly play sound.
